###############################################################################
# DONE: 1. (2 pts)
#   
#   This module is going to look very similar to other modules that you have
#   done with lists and tuples, but this time we will use sets instead.
#
#   For this _TODO_, simply create a set called colors that will have a
#   collection of strings that represent different colors. Choose whichever
#   colors you like, but make sure you have at least 4 different colors in your
#   set.
#
#   Once you have created the set, make sure to print out the set.
#
#   Once you have done this, then change the above _TODO_ to DONE.
###############################################################################
colors = {"blue", "pink", "green", "purple"}
print(colors)
###############################################################################
# DONE: 2. (2 pts)
#   
#   For this _TODO_, write a line of code that accesses a particular item in
#   the set (you choose which item) and prints the item.
#
#   Once you have done this, then change the above _TODO_ to DONE.
###############################################################################
for x in colors: 
    if "blue" == x:
        print(x)
###############################################################################
# DONE: 3. (2 pts)
#   
#   For this _TODO_, write a line of code that adds a color to your set. Once
#   you have done this, print the set. Make sure you do NOT create a new set,
#   but actually modify the original.
#
#   Once you have done this, then change the above _TODO_ to DONE.
###############################################################################
colors.add("beige")
print(colors)
###############################################################################
# DONE: 4. (2 pts)
#   
#   For this _TODO_, write a line of code that removes the same item that you
#   added from the previous _todo_. Once you have done this, print the set.
#   Make sure you do NOT create a new set, but actually modify the original.
#
#   Once you have done this, then change the above _TODO_ to DONE.
###############################################################################
colors.remove("green")
print(colors)

###############################################################################
# DONE: 5. (2 pts)
#
#   For this _TODO_, write a line of code that adds a duplicate item to your
#   set (you choose which item). Once you have done this, print the set. Make
#   sure you do NOT create a new set, but actually modify the original.
#
#   NOTE: Notice how you will not see duplicate values when it is printed.
#
#   Once you have done this, then change the above _TODO_ to DONE.
###############################################################################
colors.add("pink")
print(colors)



